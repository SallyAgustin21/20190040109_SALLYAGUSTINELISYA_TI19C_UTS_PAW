<?php
include('koneksi.php');
session_start();
if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{
	include ('header2.php');
	?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header" > Data Arsip Surat </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
                        <!-- /.panel-body -->
                       
  <?php
  include ('footer.php');
 }