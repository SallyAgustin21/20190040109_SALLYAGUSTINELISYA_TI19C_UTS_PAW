<?php 
include('koneksi.php');
	session_start();
if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
		}
		
		?>

		<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
		<h1 class="page-header" align="center"> Form Tambah Divisi </h1>
		<form class='form-horizontal' enctype="multipart/form-data" method="POST">
			<table class='table'>
			
			<tr>
				<td> NAMA DIVISI </td>
				<td> : <input type="text" class="form-control" name="nama_divisi" required=""></td>
			</tr>
			
			<tr>
				<td> KETERAGAN </td>
				<td> : <input type="text" class="form-control" name="keterangan" required=""></td>
			</tr>
			
			
			
<tr>
		<td colspan="3"><input type="submit" name="simpan" value="Simpan" class="btn btn-success"> </td>
	</tr>

	</table>
	</form>
	</div>
	<!-- /.col-lg-12-->
	</div>
	<!-- /.row -->

<?php 
if(isset($_POST['simpan'])){

	$nama=$_POST['nama_divisi'];
	$keterangan=$_POST['keterangan'];
	
	

	
	$user=$_SESSION['user'];
	
{
	$sberita=$connect->query("INSERT INTO tb_divisi(nama_divisi,keterangan)
											VALUES('$nama','$keterangan')");
	
	if(!$sberita)
	{
		echo $connect->error;
		}
	
	else{
		//header('location:formAdd.php');
		echo "<script type='text/javascript'> alert ('Data Berhasil Ditambah');"
			."window.location='divisi.php';</script>";
			}

		}
		}
		?>
	<?php include('footer.php');
	
	?>
	
