<?php
	if(isset($_POST['name1'])){
	include('koneksi.php');
	
	$user=$_POST['username'];
	$pass=$_POST['password'];
	$ak=$_POST['akses'];
	if ($ak=="admin"){
	$QL=$connect->query("SELECT * from tb_petugas WHERE username='$user' and password='$pass' and akses='$ak'");
	
	$row=$QL->fetch_object();
	$cekdata=$QL->num_rows;	
		if($cekdata > 0){
			session_start();
			$_SESSION['user']=$row->username;
			$_SESSION['id']=$row->id_petugas;
			echo "<script>window.location='../admin/index.php'</script>";
			}
		else{
		session_start();
			session_destroy();
			echo "<script>alert('Username & Password anda tidak tersed');window.location='login.php'</script>";
			$QL->close();
			}
		
		}elseif($ak=="petugas"){
			$QL=$connect->query("SELECT * from tb_petugas WHERE username='$user' and password='$pass' and akses='$ak'");
	
		$row=$QL->fetch_object();
		$cekdata=$QL->num_rows;	
		if($cekdata > 0){
			session_start();
			$_SESSION['user']=$row->username;
			
			echo "<script>window.location='../petugas/index.php'</script>";
			}
		else{
		session_start();                                                
			session_destroy();
			echo "<script>alert('Username & Password anda tidak tersedia');window.location='../admin/index.php'</script>";
			$QL->close();
			
			}
			
		}
		}