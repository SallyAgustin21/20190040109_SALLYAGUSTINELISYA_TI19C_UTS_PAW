<?php 
include('koneksi.php');
	session_start();
if(!isset($_SESSION['user'])){
	header('location:index.html');
	}else{

	

	$id=$_GET['id'];
	$query=$connect->query("Select *From surat_masuk WHERE no_agenda='$id'");
	$row=$query->fetch_object();

		}
		echo "<img src='foto/$row->cetakan_surat'>";
		?>
	<script type="text/javascript">
 		window.print();
 	</script>