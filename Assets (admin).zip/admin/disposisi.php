<?php
	include ('koneksi.php');
		session_start();
	if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
	?>
	<div id="page-wrapper">
		<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header" align="center">DATA DISPOSISI</h1>
			<h2 align="center">PT. MAJU JAYA</h2>
		
			<table class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr>
				
					<th> NO DISPOSISI </th>
					<th> NO AGENDA </th>
					<th> KEPADA </th>
					<th> KETERANGAN </th>
					<th> STATUS SURAT </th>
					<th> TANGGAPAN </th>
					<th> AKSI </th>
				</tr>
				</thead>
				<tbody>
		
		<?php
			$no=1;
			$qberita=$connect->query("Select * from tb_desposisi");
			while ($row=$qberita->fetch_object()){
			echo "<tr>";
			echo "<td>$no</td>";
			echo "<td>$row->no_agenda</td>";
			echo "<td>$row->kepada</td>";
			echo "<td>$row->keterangan</td>";
			echo "<td>$row->status_surat</td>";
			echo "<td>$row->tanggapan</td>";
			
			
				echo "<td><a href='form_editdisposisi.php?id=$row->no_disposisi' class='btn btn-warning'> EDIT</a></td>";
				echo "<td><a href='form_hapus_disposisi.php?id=$row->no_disposisi' class='btn btn-danger'> HAPUS</a></td>";
			echo "</tr>";
			$no++;
			}
			
			
               }
			?>
			</tbody>
			</table>
			</div>
			<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
			
<?php include('footer.php');

 ?>