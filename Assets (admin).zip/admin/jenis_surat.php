<?php
	include ('koneksi.php');
		session_start();
	if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
	?>
	<div id="page-wrapper">
		<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header"align="center"> DATA JENIS SURAT</h1>
			<h2 align="center">PT. MAJU JAYA</h2>
			
			<p><a href='jenis_tambah.php' class='btn btn-success'>TAMBAH DATA</a>
			<table  class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr>
					
					<th> ID JENIS </th>
					<th> JENIS SURAT </th>
					<th> KETERAGAN </th>
					<th> AKSI </th>
				</tr>
				</thead>
				<tbody>
		
		<?php
			$no=1;
			$qberita=$connect->query("Select * from tb_jenis_surat");
			while ($row=$qberita->fetch_object()){
			echo "<tr>";
			echo "<td>$no</td>";
			echo "<td>$row->jenis_surat</td>";
			echo "<td>$row->keterangan</td>";
			
				echo "<td><a href='form_editjenis.php?id=$row->id_jenis' class='btn btn-warning'> EDIT</a></td>";
				echo "<td><a href='form_hapusjenis.php?id=$row->id_jenis' class='btn btn-danger'> HAPUS</a></td>";
			echo "</tr>";
			$no++;
			}
			
			
               }
			?>
			</tbody>
			</table>
			</div>
			<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
			
<?php include('footer.php');

 ?>