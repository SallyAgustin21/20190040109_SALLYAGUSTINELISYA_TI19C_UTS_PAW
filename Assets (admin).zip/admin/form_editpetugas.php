<?php 
include('koneksi.php');
	session_start();

if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
		}
			$id=$_GET['id'];
$edit=$connect->query("select * from tb_petugas where id_petugas='$id'");
$row=$edit->fetch_Object();	
		?>

		<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
		<h1 class="page-header" align="center"> Form Edit Data Petugas </h1>
		<form class='form-horizontal' enctype="multipart/form-data" method="POST">
			<table class='table'>
			
			<tr>
				<td> NAMA PETUGAS </td>
				<td> : <input type="text" class="form-control" name="nama_petugas"  required="" value="<?=$row->nama_petugas?> "></td>
			</tr>
			
			<tr>
				<td> USERNAME </td>
				<td> : <input type="text" class="form-control" name="username" required="" value="<?=$row->username?> "></td>
			</tr>
			
			<tr>
				<td> PASSWORD </td>
				<td> : <input type="password" class="form-control" name="password" required="" value="<?=$row->password?> "></td>
			</tr>
			
			<tr>
				<td> AKSES </td>
				<td> : <input type="text" class="form-control" name="akses" required="" value="<?=$row->akses?> "></td>
			</tr>


			 
<tr>
		<td colspan="3"><input type="submit" name="simpan" value="Edit" class="btn btn-success"> </td>
	</tr>

	</table>
	</form>
	</div>
	<!-- /.col-lg-12-->
	</div>
	<!-- /.row -->

<?php 
if(isset($_POST['simpan'])){

	$nama=$_POST['nama_petugas'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$akses=$_POST['akses'];
	
	$user=$_SESSION['user'];
	
{
	$sberita=$connect->query("UPDATE tb_petugas SET nama_petugas='$nama',password='$password',akses='$akses' WHERE  username='$username'");
	
	if(!$sberita)
	{
		echo $connect->error;
		}
	
	else{
		//header('location:formAdd.php');
		echo "<script type='text/javascript'> alert ('Data Berhasil Diubah');"
			."window.location='petugas.php';</script>";
			}

		}
		}
		?>
	<?php include('footer.php');
	
	?>
	
