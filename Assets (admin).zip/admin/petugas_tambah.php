<?php 
include('koneksi.php');
	session_start();
if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
		}
		
		?>

		<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
		<h1 class="page-header" align="center"> Form Tambah Data Petugas<p></h1>
		<form class='form-horizontal' enctype="multipart/form-data" method="POST">
			<table class='table'>
			
			<tr>
				<td> NAMA PETUGAS </td>
				<td> : <input type="text" class="form-control" name="nama_petugas"  required=""></td>
			</tr>
			
			<tr>
				<td> USERNAME </td>
				<td> : <input type="text" class="form-control" name="username" required=""></td>
			</tr>
			
			<tr>
				<td> PASSWORD </td>
				<td> : <input type="password" class="form-control" name="password" required=""></td>
			</tr>

			<tr>
				<td> AKSES </td>
				<td> : <label><select name="akses" class="form-control" id="akses" required="">
				
          <option value="AKSES" selected="selected">--- AKSES ---</option>
          <option value="admin">ADMIN</option>
          <option value="petugas">PETUGAS</option>
         
        </select>
      </label></td>
			</tr>

			
<tr>
		<td colspan="3"><input type="submit" name="simpan" value="SIMPAN" class="btn btn-success"> </td>
	</tr>

	</table>
	</form>
	</div>
	<!-- /.col-lg-12-->
	</div>
	<!-- /.row -->

<?php 
if(isset($_POST['simpan'])){

	$nama=$_POST['nama_petugas'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$akses=$_POST['akses'];
	

	
	$user=$_SESSION['user'];
	
{
	$sberita=$connect->query("INSERT INTO tb_petugas(nama_petugas,username,password,akses)
											VALUES('$nama','$username','$password','$akses')");
	
	if(!$sberita)
	{
		echo $connect->error;
		}
	
	else{
		//header('location:formAdd.php');
		echo "<script type='text/javascript'> alert ('Data Berhasil Ditambah');"
			."window.location='petugas.php';</script>";
			}

		}
		}
		?>
	<?php include('footer.php');
	
	?>
	
