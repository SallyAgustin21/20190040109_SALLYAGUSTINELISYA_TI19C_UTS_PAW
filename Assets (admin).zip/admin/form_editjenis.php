<?php 
include('koneksi.php');
	session_start();

if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
		}
			$id=$_GET['id'];
$edit=$connect->query("select * from tb_jenis_surat where id_jenis='$id'");
$row=$edit->fetch_Object();	
		?>

		<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
		<h1 class="page-header" align="center"> From Edit Jenis Surat </h1>
		<form class='form-horizontal' enctype="multipart/form-data" method="POST">
			<table class='table'>
			
			<tr>
				<td> JENIS SURAT </td>
				<td> : <input type="text" class="form-control" name="jenis_surat"  required="" value="<?=$row->jenis_surat?> "></td>
			</tr>
			
			<tr>
				<td> KETERANGAN </td>
				<td> : <input type="text" class="form-control" name="keterangan" required="" value="<?=$row->keterangan?> "></td>
			</tr>
			
			

			 
<tr>
		<td colspan="3"><input type="submit" name="simpan" value="Edit" class="btn btn-success"> </td>
	</tr>

	</table>
	</form>
	</div>
	<!-- /.col-lg-12-->
	</div>
	<!-- /.row -->

<?php 
if(isset($_POST['simpan'])){

	$jenis=$_POST['jenis_surat'];
	$keterangan=$_POST['keterangan'];
	
	$user=$_SESSION['user'];
	
{
	$sberita=$connect->query("UPDATE tb_jenis_surat SET keterangan='$keterangan' WHERE  jenis_surat='$jenis'");
	
	if(!$sberita)
	{
		echo $connect->error;
		}
	
	else{
		//header('location:formAdd.php');
		echo "<script type='text/javascript'> alert ('Data Berhasil Diubah');"
			."window.location='jenis_surat.php';</script>";
			}

		}
		}
		?>
	<?php include('footer.php');
	
	?>
	
