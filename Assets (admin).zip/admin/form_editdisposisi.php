<?php 
include('koneksi.php');
	session_start();

if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
		}
			$id=$_GET['id'];
$edit=$connect->query("select * from tb_desposisi where no_disposisi='$id'");
$row=$edit->fetch_Object();	
		?>

		<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
		<h1 class="page-header" align="center"> From Edit Data Disposisi </h1>
		<form class='form-horizontal' enctype="multipart/form-data" method="POST">
			<table class='table'>
			
			<tr>
				<td> NO DISPOSISI </td>
				<td> : <input type="text" class="form-control" name="no_disposisi"  required="" value="<?=$row->no_disposisi?> " readonly></td>
			</tr>
			
			
			<tr>
				<td> STATUS SURAT </td>
				<td> : <input type="text" class="form-control" name="status_surat"  required="" value="<?=$row->status_surat?> "></td>
			</tr>
			
			<tr>
				<td> TANGGAPAN </td>
				<td> : <input type="text" class="form-control" name="tanggapan" required="" value="<?=$row->tanggapan?> "></td>
			</tr>
			
			 
<tr>
		<td colspan="3"><input type="submit" name="simpan" value="Edit" class="btn btn-success"> </td>
	</tr>

	</table>
	</form>
	</div>
	<!-- /.col-lg-12-->
	</div>
	<!-- /.row -->

<?php 
if(isset($_POST['simpan'])){
	$no_disposisi=$_POST['no_disposisi'];
	$status_surat=$_POST['status_surat'];
	$tanggapan=$_POST['tanggapan'];
	
	$user=$_SESSION['user'];
	
{
	$sberita=$connect->query("UPDATE tb_desposisi SET status_surat='$status_surat',tanggapan='$tanggapan' WHERE  no_disposisi='$no_disposisi'");
	
	if(!$sberita)
	{
		echo $connect->error;
		}
	
	else{
		//header('location:formAdd.php');
		echo "<script type='text/javascript'> alert ('Data Berhasil Diubah');"
			."window.location='disposisi.php';</script>";
			}

		}
		}
		?>
	<?php include('footer.php');
	
	?>
	
