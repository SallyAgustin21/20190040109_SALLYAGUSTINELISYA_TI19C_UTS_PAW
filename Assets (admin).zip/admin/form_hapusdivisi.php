<?php
include('koneksi.php');

$id=$_GET['id'];
$sql_hapus=$connect->query("DELETE FROM tb_divisi WHERE id_divisi='$id'");
if(!$sql_hapus)
{
    echo $connect->error;
}
else{
    echo"<script type='text/javascript'> alert('Data Berhasil Dihapus');"
    . "window.location='divisi.php';</script>";

}
?>



