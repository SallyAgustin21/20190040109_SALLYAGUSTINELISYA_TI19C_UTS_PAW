<?php
	include ('koneksi.php');
		session_start();
	if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
	?>
	<div id="page-wrapper">
		<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header" align="center">DATA SURAT KELUAR</h1>
			<h2 align="center">PT. MAJU JAYA</h2>
		
			<table class="table table-striped table-bordered table-hover " id="dataTables-example">
			<thead>
				<tr>
					<th> NO </th>
					<th> NO AGENDA KELUAR</th>
					<th> ID PETUGAS </th>
					<th> JENIS SURAT </th>
					<th> TGL KIRIM </th>
					<th> NO SURAT </th>
					<th> PENGIRIM </th>
					<th> PERIHAL </th>
					<th> CETAKAN SURAT </th>
					<th> AKSI </th>
				</tr>
				</thead>
				<tbody>
		
		<?php
			$no=1;
			$qberita=$connect->query("Select * from tb_surat_keluar");
			while ($row=$qberita->fetch_object()){
			echo "<tr>";
			echo "<td>$no</td>";
			echo "<td>$row->no_agenda_keluar</td>";
			echo "<td>$row->id_petugas</td>";
			echo "<td>$row->jenis_surat</td>";
			echo "<td>$row->tanggal_kirim</td>";
			echo "<td>$row->no_surat</td>";
			echo "<td>$row->pengirim</td>";
			echo "<td>$row->perihal</td>";
			echo "<td><img src='foto/$row->cetakan_surat' width='100' heigth='100'></td>";
			
				
				echo "<td align='center' width='15%'><div class='btn-group'>
					<a class='btn btn-primary' href='#'><i class=''></i> -- PILIH -- </a>
					<a class='btn btn-primary dropdown-toggle' data-toggle='dropdown' href='#'>
						<span class='caret'></span></a>
					<ul class='dropdown-menu'>
					<li><a href='form_hapus_suratkeluar.php?id=$row->no_agenda_keluar'><i class=''></i> HAPUS </a></li>
					<li><a href='cetak_suratkeluar.php?id=$row->no_agenda_keluar'><i class=''></i> CETAK SURAT KELUAR </a></li>
					<li><a href='cetak_gambarkeluar.php?id=$row->no_agenda_keluar'><i class=''></i> CETAK GAMBAR  </a></li>
					</ul>
					</div></td>";
				echo "</tr>";
			$no++;
			}
			
			
               }
			?>
			</tbody>
			</table>
			</div>
			<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
			
<?php include('footer.php');

 ?>