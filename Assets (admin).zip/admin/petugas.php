<?php
	include ('koneksi.php');
		session_start();
	if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
	?>
	<div id="page-wrapper">
		<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header"align="center"> DATA PETUGAS</h1>
			<h2 align="center">PT. MAJU JAYA</h2>
			
			<p><a href='petugas_tambah.php' class='btn btn-success'>TAMBAH DATA</a>
			<table  class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr>
					
					<th> ID PETUGAS </th>
					<th> NAMA PETUGAS </th>
					<th> AKSI </th>
				</tr>
				</thead>
				<tbody>
		
		<?php
			$no=1;
			$qberita=$connect->query("Select * from tb_petugas");
			while ($row=$qberita->fetch_object()){
			echo "<tr>";
			echo "<td>$no</td>";
			echo "<td>$row->nama_petugas</td>";
				echo "<td><a href='form_editpetugas.php?id=$row->id_petugas' class='btn btn-warning'> EDIT 
						<a href='form_hapuspetugas.php?id=$row->id_petugas' class='btn btn-danger'> HAPUS</a></td>";
			echo "</tr>";
			$no++;
			}
			
			
               }
			?>
			</tbody>
			</table>
			</div>
			<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
			
<?php include('footer.php');

 ?>