<?php 
include('koneksi.php');
	session_start();
if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
		}
		date_default_timezone_set('Asia/jakarta');
								$tgl=date('Ymd');
								$kode= "KLR".$tgl;
								$a=$connect->query("select max(no_agenda_keluar) as kd from tb_surat_keluar where no_agenda_keluar like '$kode%'");
								$b = $a->fetch_array();
								$c = $b['kd'];
								$d = (int) substr($c, 10, 4);
								$d++;
								$e=$kode.sprintf('%04s', $d);
								
		
		?>

		<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
		<h1 class="page-header" align="center"> From Tambah Surat Keluar <p></h1>
		<form class='form-horizontal' enctype="multipart/form-data" method="POST">
			<table class='table'>
			
			<tr>
				<td> NO AGENDA KELUAR</td>
				<td> : <input type="text" class="form-control" name="no_agenda_keluar"  value="<?php echo $e; ?>" readonly></td>
			</tr>
			
			<tr>
				<td> ID PETUGAS	</td>
				<td> : <input type="text" class="form-control" name="id_petugas" value="<?php echo ($_SESSION['user']); ?>" readonly></td>
			</tr>
			<tr>
				<td> JENIS SURAT </td>
				<td> : <select name="jenis_surat" class="form-control" required=""><?php
				$js=$connect->query("select * from tb_jenis_surat");
				while($row=$js->fetch_object()){
				echo "<option value='$row->jenis_surat'>$row->jenis_surat</option>";
				}
				?>
				</select>
				</td>
				</tr>
			
			<tr>
				<td> TANGGAL KIRIM	</td>
				<td> : <input type="date" class="form-control" name="tanggal_kirim" required=""></td>
			</tr>
	
			<tr>
				<td> NO SURAT	</td>
				<td> : <input type="text" class="form-control" name="no_surat" required=""></td>
			</tr>
			<tr>
				<td> PENGIRIM </td>
				<td> : <input type="text" class="form-control" name="pengirim" required=""></td>
			</tr>
			
			<tr>
				<td> PERIHAL</td>
				<td> : <input type="text" class="form-control" name="perihal" required=""></td>
			</tr>
			<tr>
				<td> CETAK SURAT </td>
				<td> : <input type="file" class="form-control" name="cetakan_surat" required=""></td>
			</tr>
			
			
			
<tr>
		<td colspan="3"><input type="submit" name="simpan" value="Simpan" class="btn btn-success"> </td>
	</tr>

	</table>
	</form>
	</div>
	<!-- /.col-lg-12-->
	</div>
	<!-- /.row -->

<?php 
if(isset($_POST['simpan'])){
	$no_agenda_keluar=$_POST['no_agenda_keluar'];
	$id_petugas=$_POST['id_petugas'];
	$jenis_surat=$_POST['jenis_surat'];
	$tanggal_kirim=$_POST['tanggal_kirim'];
	$no_surat=$_POST['no_surat'];
	$pengirim=$_POST['pengirim'];
	$perihal=$_POST['perihal'];
	$nama_photo=$_FILES['cetakan_surat']['name'];
	$type=$_FILES['cetakan_surat']['type'];
	$ukuran=$_FILES['cetakan_surat']['size'];
	$user=$_SESSION['user'];
	
	
{
	$uploadir='foto/';
		$alamatfile=$uploadir.$nama_photo;
		if (move_uploaded_file($_FILES['cetakan_surat']['tmp_name'],$alamatfile)){
		$sberita = $connect->query("insert into tb_surat_keluar(no_agenda_keluar,id_petugas,jenis_surat,tanggal_kirim,no_surat,pengirim,perihal,cetakan_surat)"
									."VALUES('$no_agenda_keluar','$id_petugas','$jenis_surat','$tanggal_kirim','$no_surat','$pengirim','$perihal','$nama_photo')");
	}
	if(!$sberita)
	{
		echo $connect->error;
		}
	
	else{
		//header('location:formAdd.php');
		
		echo "<script type='text/javascript'> alert ('Data Berhasil Ditambah, input Disposisi');"
			."window.location='surat_keluar.php?dis=$no_agenda_keluar';</script>";
			}
}
		}
		
		?>
	<?php include('footer.php');
	
	?>
	
