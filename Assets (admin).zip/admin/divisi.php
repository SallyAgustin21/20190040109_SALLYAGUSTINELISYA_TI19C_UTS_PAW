<?php
	include ('koneksi.php');
		session_start();
	if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
	?>
	<div id="page-wrapper">
		<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header" align="center">DATA DIVISI</h1>
			<h2 align="center">PT. MAJU JAYA</h2>
			<p><a href='divisi_tambah.php' class='btn btn-success'>TAMBAH DATA</a>
			<table  class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr>
					
					<th> ID DIVISI </th>
					<th> NAMA DIVISI </th>
					<th> KETERAGAN </th>
					<th> AKSI </th>
				</tr>
				</thead>
				<tbody>
		
		<?php
			$no=1;
			$qberita=$connect->query("Select * from tb_divisi");
			while ($row=$qberita->fetch_object()){
			echo "<tr>";
			echo "<td>$no</td>";
			echo "<td>$row->nama_divisi</td>";
			echo "<td>$row->keterangan</td>";
			
				echo "<td><a href='form_editdivisi.php?id=$row->id_divisi' class='btn btn-warning'> EDIT</a></td>";
				echo "<td><a href='form_hapusdivisi.php?id=$row->id_divisi' class='btn btn-danger'> HAPUS</a></td>";
			echo "</tr>";
			$no++;
			}
			
			
               }
			?>
			</tbody>
			</table>
			</div>
			<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
			
<?php include('footer.php');

 ?>