<?php 
include('koneksi.php');
	session_start();
if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{
	$no=$_GET['dis'];
	include('header.php');
		}
		
		?>

		<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
		<h1 class="page-header" align="center"> Tambah Data Disposisi</h1>
		<form class='form-horizontal' enctype="multipart/form-data" method="POST">
			<table class='table'>
			
			
			<tr>
				<td> NO AGENDA	</td>
				<td> : <input type="text" class="form-control" value="<?php echo $no;?>" name="no_agenda" readonly></td>
			</tr>
			<tr>
				<td> KEPADA </td>
				<td> : <select name="kepada" class="form-control" required="">
				<?php
				$js=$connect->query("select * from tb_divisi");
				while($row=$js->fetch_object()){
				echo "<option value='$row->nama_divisi'>$row->nama_divisi</option>";
				}
				?>
				</select>
				</td>
			</tr>
			
			<tr>
				<td> KETERANGAN	</td>
				<td> : <input type="text" class="form-control" name="keterangan" required=""></td>
			</tr>
			<tr>
				<td> STATUS SURAT </td>
				<td> : <input type="text" class="form-control" name="status_surat" required=""></td>
			</tr>
			
			<tr>
				<td> TANGGAPAN	</td>
				<td> : <input type="text" class="form-control" name="tanggapan" required=""></td>
			</tr>
			
			
			
			
<tr>
		<td colspan="3"><input type="submit" name="simpan" value="Simpan" class="btn btn-success"> </td>
	</tr>

	</table>
	</form>
	</div>
	<!-- /.col-lg-12-->
	</div>
	<!-- /.row -->

<?php 
if(isset($_POST['simpan'])){
	
	$no_agenda=$_POST['no_agenda'];
	$kepada=$_POST['kepada'];
	$keterangan=$_POST['keterangan'];
	$status_surat=$_POST['status_surat'];
	$tanggapan=$_POST['tanggapan'];
	
	$user=$_SESSION['user'];
	
	
{
	$sberita=$connect->query("INSERT INTO tb_desposisi(no_agenda,kepada,keterangan,status_surat,tanggapan)
											VALUES('$no_agenda','$kepada','$keterangan','$status_surat','$tanggapan')");
	
	if(!$sberita)
	{
		echo $connect->error;
		}
	
	else{
		//header('location:formAdd.php');
		
		echo "<script type='text/javascript'> alert ('Data Berhasil Ditambah');"
			."window.location='surat_masuk.php';</script>";
			}
}
		}
		
		?>
	<?php include('footer.php');
	
	?>
	
