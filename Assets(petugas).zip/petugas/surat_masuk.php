<?php
	include ('koneksi.php');
		session_start();
	if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{

	include('header.php');
	?>
	<div id="page-wrapper">
		<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header" align="center">DATA SURAT MASUK</h1>
			<h2 align="center">PT. MAJU JAYA</h2>
		
			<table  class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr>
					<th> NO </th>
					<th> NO AGENDA </th>
					<th> ID PETUGAS </th>
					<th> JENIS SURAT </th>
					<th> TGL KIRIM </th>
					<th> TGL TERIMA </th>
					<th> NO SURAT </th>
					<th> PENGIRIM </th>
					<th> PERIHAL </th>
					<th> CETAKAN SURAT </th>
					<th> AKSI </th>
				</tr>
				</thead>
				<tbody>
		
		<?php
			$no=1;
			$qberita=$connect->query("Select * from surat_masuk");
			while ($row=$qberita->fetch_object()){
			echo "<tr>";
			echo "<td>$no</td>";
			echo "<td>$row->no_agenda</td>";
			echo "<td>$row->id_petugas</td>";
			echo "<td>$row->jenis_surat</td>";
			echo "<td>$row->tanggal_kirim</td>";
			echo "<td>$row->tanggal_terima</td>";
			echo "<td>$row->no_surat</td>";
			echo "<td>$row->pengirim</td>";
			echo "<td>$row->perihal</td>";
			echo "<td><img src='foto/$row->cetakan_surat' width='100' heigth='100'></td>";
			
				echo "<td align='center' width='15%'><div class='btn-group'>
					<a class='btn btn-primary' href='#'><i class=''></i> -- PILIH -- </a>
					<a class='btn btn-primary dropdown-toggle' data-toggle='dropdown' href='#'>
						<span class='caret'></span></a>
					<ul class='dropdown-menu'>
					<li><a href='form_hapus_suratmasuk.php?id=$row->no_agenda'><i class=''></i> HAPUS </a></li>
					<li><a href='cetak_suratmasuk.php?id=$row->no_agenda'><i class=''></i> CETAK SURAT MASUK </a></li>
					<li><a href='cetak_gambarmasuk.php?id=$row->no_agenda'><i class=''></i> CETAK GAMBAR  </a></li>
					</ul>
					</div></td>";
			echo "</tr>";
			$no++;
			}
			
			
               }
			?>
			</tbody>
			</table>
			</div>
			<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
			
<?php include('footer.php');

 ?>