<?php  

session_start();
$a=session_destroy();

if ($a) {
	echo "<script>";
	echo "alert('Berhasil Keluar'); window.location='login.php'";
	echo "</script>";
}else{
	echo "<script>";
	echo "alert('Gagal Keluar'); window.location='main.php'";
	echo "</script>";
}


?>