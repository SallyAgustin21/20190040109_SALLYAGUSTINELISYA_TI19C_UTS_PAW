<?php
	if(isset($_POST['name1'])){
	include('koneksi.php');
	$user=$_POST['username'];
	$pass=($_POST['password']);
	$ak=$_POST['akses'];
	
	if($ak=='admin'){
	$QL=$connect->query("SELECT * from tb_petugas WHERE username='$user' and password='$pass' and akses='$ak'");
	$row=$QL->fetch_object();
	$cekdata=$QL->num_rows;	
	
		if($cekdata > 0){
			session_start();
			$_SESSION['user']=$row->username;
			echo "<script>alert('SELAMAT DATANG ADMIN');window.location='../admin/index.php'</script>";
			}
			else
			{
		session_start();
			session_destroy();
			echo "<script>alert('Anda Gagal Login ADMIN');window.location='login.php'</script>";
			$QL->close();
			}
	}
	else
	{
	$QL=$connect->query("SELECT * from tb_petugas WHERE username='$user' and password='$pass' and akses='$ak'");
	$row=$QL->fetch_object();
	$cekdata=$QL->num_rows;	
	
		if($cekdata > 0){
			session_start();
			$_SESSION['user']=$row->username;
			echo "<script>alert('SELAMAT DATANG PETUGAS');window.location='../admin/petugas/index.php'</script>";
			}
			else
			{
		session_start();
			session_destroy();
			echo "<script>alert('Anda Gagal Login PETUGAS');window.location='login.php'</script>";
			$QL->close();
			}
	}
	
	
			}
?>