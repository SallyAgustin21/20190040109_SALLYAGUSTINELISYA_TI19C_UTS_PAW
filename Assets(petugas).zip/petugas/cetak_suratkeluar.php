<?php 
include('koneksi.php');
	session_start();
if(!isset($_SESSION['user'])){
	header('location:login.php');
	}else{
	$id=$_GET['id'];
	$query=$connect->query("Select *From tb_surat_keluar WHERE no_agenda_keluar='$id'");
	$row=$query->fetch_object();

		}
		
	?>

<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h3 class="title" align="center">Surat</h3>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
                                <thead>
                            <tr>
                    <th> NO </th>
					<th> NO AGENDA KELUAR </th>
					<th> ID PETUGAS </th>
					<th> JENIS SURAT </th>
					<th> TGL KIRIM </th>
					<th> NO SURAT </th>
					<th> PENGIRIM </th>
					<th> PERIHAL </th>
					<th> CETAKAN SURAT </th>
					<th> AKSI </th>
                            </tr>
                        </thead>
                        <tbody>
                        	<?php
                            $no=1;
            $suratmsk=$connect->query("select *from tb_surat_keluar");
            while ($row=$suratmsk->fetch_object()){
            echo "<tr>";
            echo "<td>$no</td>";
			echo "<td>$row->no_agenda_keluar</td>";
			echo "<td>$row->id_petugas</td>";
			echo "<td>$row->jenis_surat</td>";
			echo "<td>$row->tanggal_kirim</td>";
			echo "<td>$row->no_surat</td>";
			echo "<td>$row->pengirim</td>";
			echo "<td>$row->perihal</td>";
			echo "<td>$row->cetakan_surat</td>";
            echo "</tr>";
                            $no++;
                            }
                            ?>
                             </tbody>
</table>

</div>
</div>
	<script type="text/javascript">
 		window.print();
 	</script>