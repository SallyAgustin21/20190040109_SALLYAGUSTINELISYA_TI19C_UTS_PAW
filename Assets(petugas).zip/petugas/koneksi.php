<?PHP
define('NAMA_HOST','localhost');
define('NAMA_DB','db_arsip_surat');
define('USER_DB','root');
define('USER_PASS','');

$connect = new Mysqli (NAMA_HOST,USER_DB,USER_PASS,NAMA_DB);
if($connect->connect_errno)
{
    die("ERROR : ->" . $connect->connect_error);
    exit();
}
?>

