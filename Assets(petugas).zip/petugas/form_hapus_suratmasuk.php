<?php
include('koneksi.php');

$id=$_GET['id'];
$sql_hapus=$connect->query("DELETE FROM surat_masuk WHERE no_agenda='$id'");
if(!$sql_hapus)
{
    echo $connect->error;
}
else{
    echo"<script type='text/javascript'> alert('Data Berhasil Dihapus');"
    . "window.location='surat_masuk.php';</script>";

}
?>



