<?php
include('koneksi.php');

$id=$_GET['id'];
$sql_hapus=$connect->query("DELETE FROM tb_surat_keluar WHERE no_agenda_keluar='$id'");
if(!$sql_hapus)
{
    echo $connect->error;
}
else{
    echo"<script type='text/javascript'> alert('Data Berhasil Dihapus');"
    . "window.location='surat_keluar.php';</script>";

}
?>



