-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 27 Feb 2018 pada 16.09
-- Versi Server: 10.1.8-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_arsip_surat`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `surat_masuk`
--

CREATE TABLE `surat_masuk` (
  `no_agenda` varchar(50) NOT NULL,
  `id_petugas` varchar(50) NOT NULL,
  `jenis_surat` varchar(50) NOT NULL,
  `tanggal_kirim` date NOT NULL,
  `tanggal_terima` date NOT NULL,
  `no_surat` varchar(50) NOT NULL,
  `pengirim` varchar(50) NOT NULL,
  `perihal` varchar(50) NOT NULL,
  `cetakan_surat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `surat_masuk`
--

INSERT INTO `surat_masuk` (`no_agenda`, `id_petugas`, `jenis_surat`, `tanggal_kirim`, `tanggal_terima`, `no_surat`, `pengirim`, `perihal`, `cetakan_surat`) VALUES
('MSK201802270001', 'anne', 'Surat Dinas', '2018-02-02', '0000-00-00', 'V/ABC/III', 'Anne', 'pemberitahuan', 'contoh-surat-dinas-resmi.jpg'),
('MSK201802277001', 'anne', 'Surat Sosial', '2018-02-10', '0000-00-00', 'VI/ABC/III', 'Sally', 'Undangan', 'menulis-surat-21-638.jpg'),
('MSK201802277771', 'anne', 'Surat Sosial', '2018-02-09', '0000-00-00', 'XI/SOSIAL/IV', 'Caca', 'pemberitahuan', 'contoh-surat-dinas-resmi.jpg'),
('MSK201802277778', 'anne', 'Surat Pengantar', '2018-02-09', '0000-00-00', 'iii/dktr/2018', 'Dr. Jojo', 'Pengantar', 'image1.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_desposisi`
--

CREATE TABLE `tb_desposisi` (
  `no_disposisi` int(11) NOT NULL,
  `no_agenda` varchar(50) NOT NULL,
  `kepada` varchar(50) NOT NULL,
  `keterangan` text NOT NULL,
  `status_surat` varchar(50) NOT NULL,
  `tanggapan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_desposisi`
--

INSERT INTO `tb_desposisi` (`no_disposisi`, `no_agenda`, `kepada`, `keterangan`, `status_surat`, `tanggapan`) VALUES
(4, 'MSK201802270001', 'Direktur Keuangan', '-', 'sedang diproses', 'sedang diproses'),
(5, 'MSK201802277001', 'Manager', '-', 'sedang diproses', 'sedang diproses'),
(6, 'MSK201802277701', 'Direktur Utama', '-', 'sedang diproses', 'sedang diproses'),
(7, 'MSK201802277771', 'Direktur', '-', 'sedang diproses', 'sedang diproses'),
(8, 'MSK201802277778', 'Manager', '-', 'sedang diproses', 'sedang diproses');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_divisi`
--

CREATE TABLE `tb_divisi` (
  `id_divisi` int(11) NOT NULL,
  `nama_divisi` varchar(50) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_divisi`
--

INSERT INTO `tb_divisi` (`id_divisi`, `nama_divisi`, `keterangan`) VALUES
(1, 'Direksi', 'Menetukan usaha sebagai pimipinan umum dalam megelola perusahan'),
(2, 'Direktur Utama', 'Merencanakan dan mengembangkan sumber-sumber pendapan serta pembelian dan kekayaan perusahaan.'),
(3, 'Direktur', 'Menetapkan prosedur kegiatab perusahaan ditiap-tiap manajer untuk mencapai sasaran yang ditetapkan perusahaan.'),
(4, 'Direktur Keuangan', 'Mengawasi operasional mengenai keuangan perusahaan'),
(5, 'Manager', 'Bertugas mengintegrasikan berbagai macam variabel (karakteristik, budaya, pendidikan, dsb) kedalam suatu tujuan organisasi yang sama dengan cara melakukan mekanisme penyesuaian');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_jenis_surat`
--

CREATE TABLE `tb_jenis_surat` (
  `id_jenis` int(11) NOT NULL,
  `jenis_surat` varchar(50) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_jenis_surat`
--

INSERT INTO `tb_jenis_surat` (`id_jenis`, `jenis_surat`, `keterangan`) VALUES
(2, 'Surat Sosial', 'Merupaka surat dari pihak lembaga ssial yag ditujuka kepada perorangan, perusahaan, atau pun organisasi tertetu'),
(3, 'Surat Setengah Resmi', 'Merupakan surat dari perorangan yang ditunjukan kepada lembaga organisasi atau instansi tertentu.'),
(4, 'Surat Niaga', 'Merupakan surat yang dibuat oleh sebuah perusahaan yang bergerak dibidang perniagaan atau penjualan produk'),
(5, 'Surat Pengantar', 'Merupakan yang diberikan kepada perorangan atau suatu lembaga sebagai pengantar atau acuan seseorang guna menjalin relasi dengan pihak penerima surat'),
(6, 'Surat Dinas', 'Merupakan surat yang berisi mengenai permasalah kedinasan atau pemerintahan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_petugas`
--

CREATE TABLE `tb_petugas` (
  `id_petugas` int(11) NOT NULL,
  `nama_petugas` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `akses` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_petugas`
--

INSERT INTO `tb_petugas` (`id_petugas`, `nama_petugas`, `username`, `password`, `akses`) VALUES
(11, 'Anne', 'anne', '123', 'admin'),
(12, 'Sally ', 'sally', '123', 'admin'),
(13, 'Dea', 'dea', '123', 'petugas'),
(14, 'Agustin', 'agustin', '123', 'petugas'),
(16, 'Elisya', 'elisya', '123', 'petugas');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_surat_keluar`
--

CREATE TABLE `tb_surat_keluar` (
  `no_agenda_keluar` varchar(50) NOT NULL,
  `id_petugas` varchar(50) NOT NULL,
  `jenis_surat` varchar(50) NOT NULL,
  `tanggal_kirim` date NOT NULL,
  `no_surat` varchar(50) NOT NULL,
  `pengirim` varchar(50) NOT NULL,
  `perihal` varchar(50) NOT NULL,
  `cetakan_surat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_surat_keluar`
--

INSERT INTO `tb_surat_keluar` (`no_agenda_keluar`, `id_petugas`, `jenis_surat`, `tanggal_kirim`, `no_surat`, `pengirim`, `perihal`, `cetakan_surat`) VALUES
('KLR201802270001', 'anne', 'Surat Setengah Resmi', '2018-02-17', 'V/ABC/III', 'Anne', 'Undangan', 'GAMBAR SURAT UNDANGAN.jpg'),
('KLR201802277001', 'anne', 'Surat Dinas', '2018-02-11', 'VI/ABC/III', 'Sally', 'Perijinan', 'contoh-surat-permohonan-2.jpg'),
('KLR201802277701', 'anne', 'Surat Dinas', '2018-02-04', 'XII/SMI/2018', 'Susan', 'Permohonan', 'contoh surat dinas.jpg'),
('KLR201802277771', 'anne', 'Surat Setengah Resmi', '2018-02-18', 'X/SMU/2018', 'Desi', 'Pengumuman', 'menulis-surat-21-638.jpg'),
('KLR201802277778', 'anne', 'Surat Pengantar', '2018-02-10', 'VIII/SMI/2018', 'Salsa', 'Pengantar', 'GAMBAR SURAT UNDANGAN.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `surat_masuk`
--
ALTER TABLE `surat_masuk`
  ADD PRIMARY KEY (`no_agenda`);

--
-- Indexes for table `tb_desposisi`
--
ALTER TABLE `tb_desposisi`
  ADD PRIMARY KEY (`no_disposisi`);

--
-- Indexes for table `tb_divisi`
--
ALTER TABLE `tb_divisi`
  ADD PRIMARY KEY (`id_divisi`);

--
-- Indexes for table `tb_jenis_surat`
--
ALTER TABLE `tb_jenis_surat`
  ADD PRIMARY KEY (`id_jenis`);

--
-- Indexes for table `tb_petugas`
--
ALTER TABLE `tb_petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indexes for table `tb_surat_keluar`
--
ALTER TABLE `tb_surat_keluar`
  ADD PRIMARY KEY (`no_agenda_keluar`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_desposisi`
--
ALTER TABLE `tb_desposisi`
  MODIFY `no_disposisi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tb_divisi`
--
ALTER TABLE `tb_divisi`
  MODIFY `id_divisi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tb_jenis_surat`
--
ALTER TABLE `tb_jenis_surat`
  MODIFY `id_jenis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tb_petugas`
--
ALTER TABLE `tb_petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
